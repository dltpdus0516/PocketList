package com.cookandroid.pocketlist;

public class ColorCnt {

    int colorCnt;

    public ColorCnt(){}
    public ColorCnt(int colorCnt){
        this.colorCnt = colorCnt;
    }

    public int getColorCnt(){
        return colorCnt;
    }
}
