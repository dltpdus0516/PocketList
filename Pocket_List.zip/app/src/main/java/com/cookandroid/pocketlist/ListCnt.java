package com.cookandroid.pocketlist;

public class ListCnt {

    int listCnt;

    public ListCnt(){}
    public ListCnt(int listCnt){
        this.listCnt = listCnt;
    }

    public int getListCnt(){
        return listCnt;
    }
}
